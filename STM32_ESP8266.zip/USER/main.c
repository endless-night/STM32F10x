#include "stm32f10x.h"
#include "main.h"
#include "led.h"


 
int main(void)
{	
//	char *st;
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	LED_Init();
  delay_init();	    	 //��ʱ������ʼ��	
	uart_init(115200);
	ESP8266_init();
	ESP8266_JoinAP( "Redmi" , "15297715279" );
	ESP8266_Link_Server( enumTCP , "192.168.1.7","8081" , Single_ID );
	ESP8266_UnvarnishSend();
	while(1)
	{
		ESP8266_SendString(ENABLE,"text ok",7,Single_ID);
		delay_ms(1000);
		if(ESP8266_Quit_Trans())
			LED0=0;		
	}
}
