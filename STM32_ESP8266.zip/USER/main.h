#ifndef __MAIN_H
#define __MAIN_H	





#include "sys.h"
#include <stdbool.h>
#include <string.h> 
//#include <stdio.h>  
#include  <stdlib.h>
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "wifi_config.h"
#include "wifi_function.h"




#endif
